System Folder
*************

The system folder contains a file called layouts.json. This file provides the information used by the
toolbar to retrieve the layouts, allowing you to associate a layout with a page. It contains the url 
to the layout directory, the id of the layout, the url to the icon which will be used as a thumbnail 
in the toolbar, and the title that will display with the thumbnail.

If you add a new layout you must add an entry for it to this file.

