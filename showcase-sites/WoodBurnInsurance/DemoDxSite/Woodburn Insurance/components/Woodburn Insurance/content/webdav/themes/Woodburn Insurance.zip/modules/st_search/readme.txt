st_search
=========
This module manages the CSS and javascript used by the search component of the
theme. The javascript manages the behavior of the search button, while the CSS
handles styling and the transitions of the seach box.

How to use this module
----------------------
Simply add "st_search" to your profile's module list to enable this module.
Note that changing the class and id prefixes of your theme will require updates
to both config/searchbox.js and head/searchbox.css