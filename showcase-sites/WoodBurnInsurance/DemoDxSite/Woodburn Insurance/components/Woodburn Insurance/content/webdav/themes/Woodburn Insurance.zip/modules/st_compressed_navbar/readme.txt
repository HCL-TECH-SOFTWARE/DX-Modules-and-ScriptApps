st_compressed_navbar
====================
This module shrinks the navbar when the user scroll down a page and restores it
to it's normal height when scrolling up or when they hover their mouse over the
navbar.

How to use this module
----------------------
Simply add "st_compressed_navbar" to your profile's module list to enable this
module. Note that changing the class and id prefixes of your theme will
require updates to both config/compressed_navbar.js and
head/compressed_navbar.css