st_notice
=========
This module manages the CSS and Javascript used by the notice component of the
theme. The javascript code loads strings into the elements and adds and removes
classes for hiding and displaying. The CSS styles the element and CSS3
Transitions are used to slide out the element

How to use this module
----------------------
Simply add "st_notice" to your profile's module list to enable this module.
Note that changing the class and id prefixes of your theme will require updates
to both head/notice.js and head/notice.css